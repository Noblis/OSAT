Read Me File for Summary File 3 (SF 3)


The geographic selections in the *geo.txt file may not have matching data values in the *data.txt files. This is because data from PCT and HCT series tables in Summary File 3 are not available for block groups. In addtion, Quick Tables that contain data sourced from PCT or HCT series tables are not available for block groups.

For complete information about this data set, consult the technical documentation available at:

http://www.census.gov/prod/cen2000/doc/sf3.pdf
