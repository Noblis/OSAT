Read Me File for Summary File 1 (SF 1)

The geographic selections in the *geo.txt file may not have matching data values in the *data.txt files. This is because data from the PCT tables in Summary File 1 are not available for blocks or block groups. In addition, Quick Tables that contain data sourced from PCT series tables are not available for blocks or block groups.

For complete information about this data set, consult the technical documentation available at:

http://www.census.gov/prod/cen2000/doc/sf1.pdf
